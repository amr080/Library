# Lithic OpenAPI

[OpenAPI](https://github.com/OAI/OpenAPI-Specification/) definitions for the [Lithic API](https://docs.lithic.com/docs).
